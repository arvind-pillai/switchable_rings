README
1) /PDBs contains the PDBs for LHD and hinge building blocks, inducible homodimers, dihedral assemblies and ring assemblies described in the main text in folders labelled accordingly.
2) /Supplementary_data includes raw data csvs for FP, FRET, luciferase and MP data.
3) Design_sequences.txt includes the protein sequences of key allosteric designs tested in the main figures of Pillai et al. 2024