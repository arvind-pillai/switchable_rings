#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  7 16:45:33 2022

@author: apillai1
"""
import numpy as np
from numpy import array, exp
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt 
import math
import sys

def binding_func(x,vm, k,n,baseline):
    f = (vm*(x)/(k+x))+baseline
    return f


def frac_func1(x, vm, k, n,baseline):
    lum = (vm*(x**n)/(k**n+x**n))+baseline
    return lum 

def frac_func2(x,b):
    lum = ((x)/(b+x))
    return lum 

max_conc = 10*10**-6
no_of_wells = 24
S = [] #S is a list of Log10(conc) for all the reps
S_exp = [] #S is a list of (conc) for all the reps
names = ["Rep1","rep2","rep3","rep4"]
for i in range (no_of_wells):
  S.append(math.log10(max_conc))
  S_exp.append(max_conc)
  max_conc = max_conc/2

filename = sys.argv[1]
infile = open(sys.argv[1],"r")
rep = 0
line = infile.readline()
kd_list = []
while (line):
  count = 0
  L = []
  while (count<24):
    line = line.strip()
    k = line.split()
    print (k)
    polarization = k[-1]
    line = infile.readline()
    L.append(float(polarization))
    
    count+=1
  plt.scatter(S,L)
 
    
 
  print (L)
  print (S)
  baseline = L[-1] #This is the baseline
  params, covs = curve_fit(frac_func1, S_exp, L, p0 = [100,1,1,baseline])
  vm = params[0]
  k = params[1]
  n = params[2]
  baseline = params[3]
  print (names[rep],"Kd",k,"n",n,"vm",vm,"variance",np.diag(covs))
  kd_list.append(k)
  x = []
  y = []
  i= -12
  while (i<-5):

      x.append(i)
      y.append(frac_func1(10**i,vm,k,n,baseline))
      i+=0.001

  plt.plot(x,y)
  rep+=1
plt.legend(names)
plt.xlabel("Concentration log scale (uM)")
plt.ylabel("Fluorescence polarization")  
plt.savefig(sys.argv[1]+".svg")
infile.close()
print (np.mean(kd_list), np.std(kd_list))
plt.close()


