#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jan  7 16:45:33 2022

@author: apillai1
"""
import numpy as np
from numpy import array, exp
from scipy.optimize import curve_fit
import matplotlib.pyplot as plt 
import math

def frac_func1(x, vm, k, n,baseline):
    lum = (vm*(x**n)/(k**n+x**n))+baseline
    return lum 

#A10_two_label_FRET
L= [[4466.0, 5138.0, 5213.0, 5221.0, 5386.0, 5200.0, 5231.0, 5425.0, 5519.0, 5761.0, 6076.0, 6418.0, 6641.0, 6730.0, 7170.0, 7167.0, 7513.0, 7210.0, 7408.0, 7387.0, 7485.0, 7380.0, 7631.0, 8647.0],[4585.0, 5276.0, 5437.0, 5511.0, 5533.0, 5628.0, 5448.0, 5823.0, 5864.0, 6248.0, 6298.0, 6578.0, 7159.0, 7215.0, 7329.0, 7265.0, 7571.0, 7524.0, 7847.0, 7925.0, 7795.0, 8117.0, 7814.0, 8990.0],[4580.0, 5308.0, 5629.0, 5781.0, 5604.0, 5923.0, 5782.0, 6001.0, 6291.0, 6651.0, 7099.0, 7091.0, 7768.0, 7874.0, 8263.0, 8126.0, 8385.0, 8408.0, 8904.0, 8692.0, 8665.0, 8976.0, 8657.0, 9330.0],[4225.0, 5129.0, 5597.0, 5756.0, 5651.0, 5706.0, 5793.0, 5993.0, 6087.0, 6403.0, 7090.0, 7055.0, 7817.0, 8332.0, 8187.0, 8415.0, 8564.0, 8534.0, 8701.0, 8822.0, 8846.0, 8904.0, 8982.0, 9396.0]]


max_conc = 100*10**-6
no_of_wells = 23
S = [] #S is a list of Log10(conc) for all the reps
S_exp = [] #S is a list of (conc) for all the reps
names = ["Rep1","rep2","rep3","rep4"]
for i in range (no_of_wells):
  S.append(math.log10(max_conc))
  S_exp.append(max_conc)
  max_conc = max_conc/2



#A10_FRET
L= [[2683,2489,2578,2507,2557,2629,2508,2454,2261,2178,1726,2224,1991,2085,1888,1925,1874,1983,1898,1976,1838,1953,1875],[2672.0, 2744.0, 2636.0, 2632.0, 2495.0, 2642.0, 2559.0, 2471.0, 2518.0, 2335.0, 2111.0, 2130.0, 2015.0, 1888.0, 2021.0, 1967.0, 2010.0, 1935.0, 1954.0, 1897.0, 1961.0, 1942.0, 1851.0],[2693.0, 2638.0, 2492.0, 2582.0, 2454.0, 2464.0, 2447.0, 2425.0, 2264.0, 2217.0, 2024.0, 1996.0, 1960.0, 1853.0, 1754.0, 1876.0, 1851.0, 1802.0, 1799.0, 1772.0, 1682.0, 1780.0, 1863.0],[2652.0, 2485.0, 2583.0, 2665.0, 2613.0, 2440.0, 2357.0, 2149.0, 2286.0, 2125.0, 2125.0, 1978.0, 2007.0, 1843.0, 1870.0, 1862.0, 1763.0, 1821.0, 1883.0, 1818.0, 1925.0, 1863.0, 1801.0]]

avg_L = []
err = []  

for i in range(len(L[0])):
  avg_L.append((L[0][i]+L[1][i]+L[2][i]+L[3][i])/4)
  err.append(np.std([L[0][i],L[1][i],L[2][i],L[3][i]])/2)
  print (avg_L[-1])
print (len(avg_L),len(S))
plt.scatter(S,avg_L)
plt.errorbar(S,avg_L, yerr=err, fmt='o')
baseline = 1841
params, covs = curve_fit(frac_func1, S_exp, avg_L,p0 = [2672,1,1,baseline])
print (params)

count = S_exp[-1]
#def frac_func1(x, vm, k, n,baseline):
x = []
y = []
while (count<S_exp[0]):
  y.append(frac_func1(count, params[0],params[1],params[2],params[3]))
  x.append(math.log10(count))
 # print (x,y)
  count+=1*10**-10
plt.axvline(math.log10(params[1]))
plt.plot(x,y) 

plt.legend(names)
plt.xlabel("Concentration log scale (uM)")
plt.ylabel("Fluorescence polarization")  
plt.savefig("A10_fitted2.svg")

plt.close()


