import numpy as np
from numpy import array, exp
from scipy.optimize import curve_fit
import scipy
import matplotlib.pyplot as plt 
import seaborn as sns
from sklearn import datasets
from sklearn.mixture import GaussianMixture
import pandas as pd
from scipy.stats import norm
from scipy.stats import skewnorm
def gauss(x,amp,my,sigma):
  return amp*np.exp(-(x-mu)**2/2*sigma**2)

fig, axs = plt.subplots(6,sharex=True)
files = ["A3P_new.csv","A7_new.csv","B1_sr312.csv","B11P_new_callibration.csv","C12P_new_callibration.csv"]
unbound = [54.354,44.227,47.918,40.723,47.085]
bound = [57.518,47.31,51.001,43.886,50.32]
number_sub = [3,3,4,5,2]
mass_range = [50,70,50,50,100]


#47157 C12
#55276 A3
#48943	B1
#45282	A7
#40839 B11, 41661

files = ["C12P_try_this.csv","A3P_attempt3.csv","A7_new.csv","B1_sr312.csv","B11P_new_callibration.csv","A7_with_Peptide.csv"]
unbound = [47.085,54.354,44.227,47.918,40.723]
bound = [50.32,57.518,47.31,51.001,43.886]
number_sub = [2,3,3,4,5,2]
mass_range = [50,50,70,50,50,50]
#JHB7 = 3163.69
#221 = 3083.62
#74 = 3.237

JHB7 = 3.16369
cs221B = 3.08362
cs74 = 3.237

bound = [47.157+cs74,54.354+JHB7,45.282+cs221B,48.943+cs221B,40.839+JHB7,61+2*cs221B]

for i in range(0,6):
   filename = files[i]
   infile = open(filename,"r")
   a = []
   for line in infile:
     if not "masses_kDa" in  line and not "#" in line and len(line)>3:
       k = line.split(",")
       if float(k[4])>0:
         a.append(float(k[4])) 
   a = np.array(a)
   for multimer in range (1,7):
     axs[i].axvline(multimer*bound[i],color="black", linestyle = '--') 
       ##   plt.axvline(multimer*unbound[i],ax=axs[i])
   plt.xlim(25, 300)
   window = []
   for elt in a:
     if elt>(number_sub[i]*bound[i])-mass_range[i] and elt<(number_sub[i]*bound[i])+mass_range[i]:
       window.append(elt)   
   print (len(window))  
   
   
   sns.histplot(a,stat="density",ax=axs[i])

   mu, std = norm.fit(window)       
   a = np.array(a)
   xmin, xmax = plt.xlim()
   x = np.linspace(xmin, xmax, 100)
   p = norm.pdf(x, mu, std)
   print (mu,number_sub[i]*bound[i], len(x), abs(mu-(number_sub[i]*bound[i]))/(number_sub[i]*bound[i]))


   axs[i].plot(x, p, 'r', lw=2, label='pdf')  
   
plt.savefig("Overlay_try.svg")
plt.close()
