import numpy as np
from numpy import array, exp
from scipy.optimize import curve_fit
import scipy
import matplotlib.pyplot as plt 
import seaborn as sns
import pandas as pd




files = ["sr508_0.csv","sr508_with_Peptide_noGFP.csv"]


for i in range(0,2):
   filename = files[i]
   infile = open(filename,"r")
   a = []
   for line in infile:
     if not "masses_kDa" in  line and not "#" in line and len(line)>3:
       k = line.split(",")
       if float(k[4])>0:
         a.append(float(k[4])) 
   a = np.array(a)
   plt.axvline(61,color="black", linestyle = '--')   
   plt.axvline(61*2,color="black", linestyle = '--')   
   plt.axvline(61*3,color="black", linestyle = '--')   
   plt.axvline(61*4,color="black", linestyle = '--')   
   plt.axvline((61+3+3),color="red", linestyle = '--')   
   plt.axvline((61+3+3)*2,color="red", linestyle = '--')   
   plt.axvline((61+3+3)*3,color="red", linestyle = '--')   
   plt.axvline((61+3+3)*4,color="red", linestyle = '--')   
       
   plt.xlim(0,400)
   sns.histplot(a,stat="density",binwidth=10)
   plt.savefig(filename+".svg")
   plt.close()
