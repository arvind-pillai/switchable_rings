import seaborn as sns
import numpy as np
import pandas as pd
import random
import matplotlib.pyplot as plt
a = [[984,1171,964,1111,1015,1160,1134,1135,880,1063],[251,254,233,262,252,256,260,212,223,261,130,144],[11652,11134,11921,11539,12010,12061,12031,12672,12402,12191],[509154,417561,474220,469502,485459,544849,614453,469816,500689,648675]]

count = 1
means = []
pos = []
errors = []
for elt in a:
  means.append(np.mean(elt))  
  errors.append(np.std(elt))  
  pos.append(count)
  count+=1
pos2 = []
for i in range (0,len(pos)):
  pos2.append(pos[i]-1)
labels = ["lgbit","smbit","lgbit+smbit","lgbit+smbit+peptide"]  
print(pos)
print (means)
df = pd.DataFrame(list(zip(means, errors,pos2,labels)),
               columns =['means', 'errors','pos','labels'])
sns.barplot(data=df, x="labels", y="means")
plt.errorbar(x=pos2, y=means, yerr=df["errors"], fmt="none", c= "k")
plt.ylabel("Luminescence a.u.")
plt.ylim(-30000,700000)
for i in range (0,4):
  rando = []
  y = []
  for j in range(len(a[i])):
    y.append(a[i][j])
    rando.append(i+random.uniform(-0.4,0.4))
  plt.scatter(rando,y)
 
plt.savefig("IHA10_allcontrols.svg")
plt.close()
a = [[204251,194967,218496],[181072,181145,178590],[144752,138506,144786],[154549,160684,176513],[88451,88122,73507],[104895,102053,101131],[70676,70692,73338],[88977,92983,107809],[68888,62422,64308],[125132,129552,126953],[52668,51926,51846],[99859,108729,103568],[407866,409269,412654],[423969,418988,422881],[28835,29214,27994],[153432,151616,151169],[432326,398448,346817],[321349,351357,370084],[20833,17405,21847],[66267,107228,165258],[494779,492016,459636],[504470,519684,485290]]

count = 1
means = []
pos = []
errors = []
for elt in a:
  means.append(np.mean(elt))  
  errors.append(np.std(elt))  
  pos.append(count)
  count+=1
pos2 = []
for i in range (0,len(pos)):
  pos2.append(pos[i]-1)
  
print(pos)
print (means)
df = pd.DataFrame(list(zip(means, errors,pos2)),
               columns =['means', 'errors','pos'])
sns.barplot(data=df, x="pos", y="means")
plt.errorbar(x=pos2, y=means, yerr=df["errors"], fmt="none", c= "k")
plt.ylabel("Luminescence a.u.")
plt.ylim(-30000,700000)
for i in range (0,len(a)):
  rando = []
  y = []
  for j in range(len(a[i])):
    y.append(a[i][j])
    rando.append(i+random.uniform(-0.4,0.4))
  plt.scatter(rando,y)
plt.savefig("Homodimer_survey.svg")
