This folder contains PDBs for key designs tested and reported in Pillai et al. 2024
/building_blocks --> PDBs for base building blocks used as inputs in WORMs
/dihedral_assemblies --> Dihedral designs in the X-state and Y-state 
/Inducible_Homodimers --> Inducible homodimers in the Y-state (from WORMs) and the X-state (from AF2)
/static_X_state_rings_soluble --> WORMs outputs for static rings in the X-state that were soluble.
/switchable_rings --> WORMs outputs for switchable rings in the Y state and the X-state predicted with alphafold-v2 (open structures) and alphafold-multimer (closed strained rings).
/sr508 --> Y and X state for the working same-state ring in Fig 2f.

For final designed sequences of rings USE THE PDBs PREDICTED WITH ALPHAFOLD IN THE X STATE. 
